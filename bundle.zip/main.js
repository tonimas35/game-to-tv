'use strict';
// Juegos del Salón for Android TV (game-to-tv 0.8.0). See src/tv-service/android.js.
require('./src/tv-service/android.js').run(process.argv.slice(2));
